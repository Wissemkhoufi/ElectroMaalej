<?php include('header.php'); ?>
<div class="main-container ace-save-state" id="main-container">
    <script type="text/javascript">
        try {
            ace.settings.loadState('main-container')
        } catch (e) {
        }
    </script>
	
	<script type="text/javascript">
function imprimer_page()
{ 
  window.print();
}
</script>

<?php include ('sidebar.php');?>

    <div class="main-content">
        <div class="main-content-inner">
            <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                <ul class="breadcrumb">
                    <li>
                        <i class="ace-icon fa fa-home home-icon"></i>
                        <a href="#">Product Management</a>                            </li>


                    <li class="active"> New product</li>
                </ul><!-- /.breadcrumb -->

                <div class="nav-search" id="nav-search">
                    <form class="form-search">
                                    <span class="input-icon">
                                        <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                                        <i class="ace-icon fa fa-search nav-search-icon"></i>
                                    </span>
                    </form>
                </div><!-- /.nav-search -->
            </div>

            <div class="page-content">
                <ul class="list-group">
                    <h2>Liste des commandes</h2>
                    <?php

                    foreach($all_commande as $commande){    ?>
                    <li class="list-group-item">
                        <h4>Commande</h4>
                        <div class="continer_commande" style="height:40px;">
                            <div class="row">
                                <div class="col-md-3">
                                    <strong> id : </strong><span><?php

                                        echo $commande->getId();?></span>
                                </div>
                                <div class="col-md-3">
                                    <strong> Date : </strong><span><?php echo $commande->getDate();?></span>
                                </div>
                                <div class="col-md-3">
                                    <strong> Prix total : </strong><span><?php echo $commande->getPrixTotal();?></span>
                                </div>
                                <div class="col-md-3">
                                    <strong> client : </strong><span><?php echo $commande->getClient()->getNom();?> <?php echo $commande->getClient()->getPrenom();?></span>
                                </div>

                            </div>

                        </div>
                        <h4>Dètail : </h4>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Produit</th>
                                <th>prix</th>
                                <th>quantite</th>
                            </tr>
                            </thead>
                            <tbody>
                         <?php foreach($commande->getProduitCommande() as $lgcommande){    ?>
                         <tr>
                                <td><?php echo $lgcommande->getProduit()->getLibelle(); ?></td>
                                <td><?php echo $lgcommande->getProduit()->getPrix(); ?></td>
                                <td><?php echo $lgcommande->getQuantite(); ?></td>
                         </tr>
                                <?php }  ?>


                            </tbody>
                        </table>
                    </li>
                    <?php }    ?>
					
					<input id="impression" name="impression" type="button" onclick="imprimer_page()" value="Imprimer toute les commandes" />
                </ul>

            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->

   <?php include('footer.php')?>
