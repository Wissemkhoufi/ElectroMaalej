<?php include('header.php'); ?>
<div class="main-container ace-save-state" id="main-container">
    <script type="text/javascript">
        try {
            ace.settings.loadState('main-container')
        } catch (e) {
        }
    </script>

    <?php include ('sidebar.php');?>

    <div class="main-content">
        <div class="main-content-inner">
            <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                <ul class="breadcrumb">
                    <li>
                        <i class="ace-icon fa fa-home home-icon"></i>
                        <a href="#">statistique commande </a>
                    </li>
                    <li class="active">les produit le plus acheté par jour</li>
                </ul><!-- /.breadcrumb -->

                <div class="nav-search" id="nav-search">
                    <form class="form-search">
                                    <span class="input-icon">
                                        <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                                        <i class="ace-icon fa fa-search nav-search-icon"></i>
                                    </span>
                    </form>
                </div><!-- /.nav-search -->
            </div>

            <div class="page-content">
                <ul class="list-group">
                    <h2>Chart grafique :</h2>
                    <div class="input-group date col-md-4" data-provide="datepicker">
                        <input type="text" class="datepicker form-control ">
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </ul>
                <p id="notification" style="display:none;"><strong>pas de commande effectuee pour ce jour</strong></p>
                <div style="height:400px;width:400px;">
                    <canvas id="myChart" width="400" height="400" style="display: none;"></canvas>
                </div>

            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->
    <script type="text/javascript">
        $(document).ready(function($){
            $('.datepicker').datepicker();
            $('.datepicker').on('change',function(){
                var value = $(this).val();
                console.log(value);
                $('#notification').hide();

                $.ajax({
                    url: '<?php echo getURl();?>?controller=admin&action=getCommandeBydate',
                    type: 'POST',
                    data:{date:value},
                    success:function(doc){

                       console.log(doc);
                       if(doc.length>0) {
                           var ctx = document.getElementById("myChart").getContext("2d");

                           $('#myChart').show();//pour afficher le charts
                           var backgroundColor = [
                               'rgba(255, 99, 132, 0.2)',
                               'rgba(54, 162, 235, 0.2)',
                               'rgba(255, 206, 86, 0.2)',
                               'rgba(75, 192, 192, 0.2)',
                               'rgba(153, 102, 255, 0.2)',
                               'rgba(255, 159, 64, 0.2)'
                           ];
                           var data_sum = [], background = [], label, labels = [];
                           $.map(doc, function (elem, i) {
                               data_sum.push(elem.sum);
                               background.push(backgroundColor[i]);
                               label = 'Nombre produit vendue pour ce jour';
                               labels.push(elem.libelle);
                           })

                           var data = {
                               datasets: [{
                                   data: data_sum,
                                   backgroundColor: background,
                                   label: label  // for legend
                               }],
                               labels: labels
                           };
                           console.log(data);
                           new Chart(ctx, {
                               data: data,
                               type: "pie",
                               options: {
                                   elements: {
                                       arc: {
                                           borderColor: "#000000"
                                       }
                                   }
                                   ,
                                   responsive: true,
                                   maintainAspectRatio: true
                               }
                           });
                       }else{
                           $('#notification').show();
                           $('#myChart').hide();
                       }
                    },
                    error: function(xhr, status, error) {
                        console.log(status);
                        console.log(error);
                        console.log(xhr.responseText);
                    }
                });
            });
        });


    </script>
    <?php include('footer.php')?>
