<div id="sidebar" class="sidebar                  responsive                    ace-save-state">
    <script type="text/javascript">
        try {
            ace.settings.loadState('sidebar')
        } catch (e) {
        }
    </script>



    <ul class="nav nav-list">
        <li class="">
            <a href="#">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Products </span>
            </a>

            <b class="arrow"></b>
        </li>



        <li class="">
            <a href="#">
                <i class="menu-icon fa fa-list-alt"></i>
                <span class="menu-text"> Providers </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a href="<?php echo getURl();?>?controller=admin&action=index">
                <i class="menu-icon fa fa-list-alt"></i>
                <span class="menu-text"> Commandes </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a href="<?php echo getURl();?>?controller=admin&action=afficher">
                <i class="menu-icon fa fa-list-alt"></i>
                <span class="menu-text"> Clients </span>
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a href="<?php echo getURl();?>?controller=admin&action=chart">
                <i class="menu-icon fa fa-list-alt"></i>
                <span class="menu-text"> chart </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a href="#">
                <i class="menu-icon fa fa-calendar"></i>

                <span class="menu-text">
                                    Orders


                                </span>
            </a>

            <b class="arrow"></b>
        </li>


    </ul><!-- /.nav-list -->

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>
</div>