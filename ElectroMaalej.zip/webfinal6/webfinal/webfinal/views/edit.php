<html>
<head>
  <meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" style="text/css" href="" />
	<script type="text/javascript" src=""></script>
</head>
<body>
<ul class="nav navbar-nav">
	<h1>Modifier Votre compte</h1>
	<center>
		<form action="?controller=client&action=update" class="form-style-1" method="POST">
			<input placeholder="email" name="email" type="email" required="">
			<input placeholder="password" name="password" type="text" required="">
			<input placeholder="dateNaissance" name="dateNaissance" type="date" required="">
			<input placeholder="adresse" name="adresse" type="text" required="">
			<input placeholder="nom" name="nom" type="text" required="">	
			<input placeholder="prenom" name="prenom" type="text" required="">
													<div class="sign-up">
														<input type="submit" value="Modif Account"/>
													</div>
		</form>
	</center>
	</ul>
</body>
</html>