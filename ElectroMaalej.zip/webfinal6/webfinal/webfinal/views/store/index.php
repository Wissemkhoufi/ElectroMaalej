<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Electronic Store a Ecommerce Online Shopping Category Bootstrap Responsive Website Template | Home :: w3layouts</title>
    <!-- for-mobile-apps -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Electronic Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //for-mobile-apps -->
    <!-- Custom Theme files -->
    <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="public/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="public/css/fasthover.css" rel="stylesheet" type="text/css" media="all" />
    <link href="public/css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
    <!-- //Custom Theme files -->
    <!-- font-awesome icons -->
    <link href="public/css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <!-- js -->
    <script src="public/js/jquery.min.js"></script>
    <link rel="stylesheet" href="public/css/jquery.countdown.css" /> <!-- countdown -->
    <!-- //js -->
    <!-- web fonts -->
    <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <!-- //web fonts -->
    <!-- start-smooth-scrolling -->
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
    </script>
    <!-- //end-smooth-scrolling -->
</head>
<body>
<!-- for bootstrap working -->
<script type="text/javascript" src="public/js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- header modal -->
<div class="modal fade" id="myModal88" tabindex="-1" role="dialog" aria-labelledby="myModal88"
     aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;</button>
                <h4 class="modal-title" id="myModalLabel"> connectez vous maintenant!</h4>
            </div>
            <div class="modal-body modal-body-sub">
                <div class="row">
                    <div class="col-md-8 modal_body_left modal_body_left1" style="border-right: 1px dotted #C2C2C2;padding-right:3em;">
                        <div class="sap_tabs">
                            <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">

                                <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
                                    <div class="facts">
                                        <div class="register">
                                            <form action="<?php echo getURl(); ?>?controller=client&action=login" method="post">
                                                <input name="email" placeholder="Email Address" type="text" required="">
                                                <input name="password" placeholder="Password" type="password" required="">
                                                <div class="sign-up">
                                                    <input class="resp-tab-item" name="login" type="submit" value="Sign in"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <ul>

                                </ul>
                            </div>
                        </div>
                        <script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
                        <script type="text/javascript">
                            $(document).ready(function () {
//                                $('#horizontalTab').easyResponsiveTabs({
//                                    type: 'default', //Types: default, vertical, accordion
//                                    width: 'auto', //auto or any width like 600px
//                                    fit: true   // 100% fit in a container
//                                });
                            });
                        </script>
                        <div id="OR" class="hidden-xs">OR</div>
                    </div>
                    <div class="col-md-4 modal_body_right modal_body_right1">
                        <div class="row text-center sign-with">
                            <div class="col-md-12">
                                <h3 class="other-nw">inscrivez vous</h3>
                            </div>
                            <div class="col-md-12">
                                 <form action="<?php echo getURl(); ?>?controller=client&action=save_client" method="post">
                                                <input name="email" placeholder="Email Address" type="text" required="">
                                                <input name="password" placeholder="Password" type="password" required="">
                                                <input name="dateNaissance" placeholder="date naissance" type="date" required="">
                                                <input name="adresse" placeholder="adresse" type="text" required="">
                                                <input name="role" placeholder="role" type="text" required="">
                                                <input name="nom" placeholder="nom" type="text" required="">
                                                <input name="prenom" placeholder="prenom" type="text" required="">

                                                <div class="sign-up">
                                                    <input class="resp-tab-item" name="login" type="submit" value="Sign in"/>
                                                </div>
                                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- header modal -->
<!-- header -->
<div class="header" id="home1">
    <div class="container">
        <div class="w3l_login">
            <a href="#" data-toggle="modal" data-target="#myModal88"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></a>
        </div>
        <div class="w3l_logo">
            <h1><a href="index.html">Dali Phone<span>Your stores. Your place.</span></a></h1>


            
        </div>
        <div class="search">
            <input class="search_box" type="checkbox" id="search_box">
            <label class="icon-search" for="search_box"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></label>
            <div class="search_form">
                <form action="#" method="post">
                    <input type="text" name="Search" placeholder="Search...">
                    <input type="submit" value="Send">
                </form>
            </div>
        </div>
        <div class="asd">
            <div id="w3lssbmincart">
                <form method="post" class="" action="<?php echo getURL(); ?>?controller=commande&action=passer_commande" target="">    <button type="button" class="sbmincart-closer">×</button>
                    <ul>
                        <?php
                        global $session;
                        global $sold;
                        if(isset($sold)){?>
                            <div class="row" style="min-height:50px;text-align:right;">
                                <?php echo "Votre solde ".$sold;?>
                            </div>


                        <?php  } ?>
                            <?php



                            $total_panier = 0;
                            if($session->session_exist('panier')){

                              foreach($session->get_Session_data('panier') as $k => $element):
                                  $total_ligne =0;
                                  $total_ligne = $element['prix'] *  $element['nb_element'];
                                  $total_panier+=$total_ligne;


                                ?>

                        <li class="sbmincart-item sbmincart-item-changed">
                            <div class="sbmincart-details-name">
                                <a class="sbmincart-name" href="http://localhost/workshop/?controller=store&amp;action=index#">  <?php echo  $element['libelle']; ?></a>
                                <ul class="sbmincart-attributes">
                                </ul>
                            </div>
                            <div class="sbmincart-details-quantity">
                                <?php echo $element['nb_element']; ?>
                            </div>
                            <div class="sbmincart-details-remove">
                                <a style="display:inline-block;" href="<?php echo getURl(); ?>?controller=produit&action=delete_from_cart&id=<?php echo $k?>" type="button" class="sbmincart-remove" data-sbmincart-idx="0">×</a>
                            </div>
                            <div class="sbmincart-details-price">
                                <span class="sbmincart-price">$<?php echo $element['prix']; ?></span>
                            </div>
                            <input type="hidden" name="w3ls_item_1" value="Mobile Phone2">
                            <input type="hidden" name="amount_1" value="302">
                            <input type="hidden" name="shipping_1" value="undefined">
                            <input type="hidden" name="shipping2_1" value="undefined">
                        </li>
                            <?php
                                endforeach;
                            }

                            ?>

                    </ul>
                    <div class="sbmincart-footer">
                        <div class="sbmincart-subtotal">                Subtotal: $<?php echo $total_panier; ?> USD            </div>
                        <button class="sbmincart-submit" data-sbmincart-alt="undefined">Passer commande</button>
                    </div>
                    <input type="hidden" name="cmd" value="_cart">
                    <input type="hidden" name="upload" value="1">
                    <input type="hidden" name="bn" value="sbmincart_AddToCart_WPS_US">    </form></div>
            <form action="#" method="post" class="last">
                <input type="hidden" name="cmd" value="_cart" />
                <input type="hidden" name="display" value="1" />
                <button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
            </form>
        </div>
    </div>
</div>
<!-- //header -->
<!-- navigation -->
<div class="navigation">
    <div class="container">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header nav_2">
                <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
                <ul class="nav navbar-nav">
                    <li><a href="index.html" class="act">Acceuil</a></li>
                    <!-- Mega Menu -->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Produits <b class="caret"></b></a>
                        <ul class="dropdown-menu multi-column columns-3">
                            <div class="row">

                                    <?php
                                    global $array_category;
                                    foreach ($array_category as $key => $value):?>
                                <div class="col-sm-3">
                                    <ul class="multi-column-dropdown">
                                        <h6><?php echo $value; ?></h6>
                                        <?php

                                        foreach ($ProductPerCategorie[$key] as $element):?>
                                        <li><a href="#.html"><?php echo $element->getLibelle(); ?></a></li>
                                        <?php endforeach;?>

                                    </ul>
                                </div>

                                    <?php endforeach;?>

                                <div class="col-sm-4">
                                    <div class="w3ls_products_pos">
                                        <h4>30%<i>Off/-</i></h4>
                                        <img src="public/images/1.jpg" alt=" " class="img-responsive" />
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </ul>
                    </li>
                    
                    <li class="w3pages"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Nos offres <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="icons.html">Smartphones</a></li>
                            <li><a href="codes.html">Tablettes</a></li>
                        </ul>
                    </li>
<!--                    <form method="post" class="" action="https://www.sandbox.paypal.com/cgi-bin/webscr" target="">    <button type="button" class="minicart-closer">×</button>    <ul>                <li class="minicart-item minicart-item-changed">            <div class="minicart-details-name">                <a class="minicart-name" href="http://minicartjs.com/">Rainbow</a>                <ul class="minicart-attributes">                                        <li>                        ROYGBIV                        <input type="hidden" name="item_number_1" value="ROYGBIV">                    </li>                                                                            </ul>            </div>            <div class="minicart-details-quantity">                <input class="minicart-quantity" data-minicart-idx="0" name="quantity_1" type="text" pattern="[0-9]*" value="2" autocomplete="off">            </div>            <div class="minicart-details-remove">                <button type="button" class="minicart-remove" data-minicart-idx="0">×</button>            </div>            <div class="minicart-details-price">                <span class="minicart-price">$4.00</span>            </div>            <input type="hidden" name="item_name_1" value="Rainbow">            <input type="hidden" name="amount_1" value="2">            <input type="hidden" name="shipping_1" value="undefined">            <input type="hidden" name="shipping2_1" value="undefined">        </li>            </ul>    <div class="minicart-footer">                    <div class="minicart-subtotal">                Subtotal: $4.00 USD            </div>            <button class="minicart-submit" type="submit" data-minicart-alt="undefined">Check Out with <img src="//cdnjs.cloudflare.com/ajax/libs/minicart/3.0.1/paypal_65x18.png" width="65" height="18" alt="PayPal"></button>            </div>    <input type="hidden" name="cmd" value="_cart">    <input type="hidden" name="upload" value="1">            <input type="hidden" name="bn" value="MiniCart_AddToCart_WPS_US">            <input type="hidden" name="business" value="example@minicartjs.com">            <input type="hidden" name="currency_code" value="USD">            <input type="hidden" name="return" value="http://www.minicartjs.com/?success">            <input type="hidden" name="cancel_return" value="http://www.minicartjs.com/?cancel">    </form>-->
                    
                    <?php if($session->session_exist('Client')){?>
                        <li><a href="<?php echo getUrl();?>?controller=client&action=logout">déconnecter</a></li>
                        <li> <a href="<?php echo getUrl();?>?controller=client&action=edit">modifier votre compte</a></li>
                    <?php }else{?>
                        <li><a id="connecter" href="#">connectez</a></li>
                    <?php }?>
                </ul>
                <section id="content">
            <?php require_once('routes.php'); ?>
        </section>
            </div>
        </nav>
    </div>
</div>

<script>
    $('#connecter').bind('click',function(e){
//        prevent default action like redirection
        e.preventDefault();
        $('#myModal88').modal('show');
    });



</script>
<!-- //navigation -->
<!-- banner -->

<?php if(isset($_GET['type']) && $_GET['type']== 'error'){?>
    <div class="alert alert-danger">
        <?php echo $_GET['message'];?>
    </div>
<?php }?>
<?php if(isset($_GET['type']) && $_GET['type']== 'success'){?>
    <div class="alert alert-success">
        <?php echo $_GET['message'];?>
    </div>
<?php }?>
<div class="banner">
    <div class="container">
        <h3>SmartPhones, <span>Offres speciales</span></h3>
    </div>
</div>
<!-- //banner -->
<!-- banner-bottom -->
<div class="banner-bottom">
    <div class="container">

<!--        <div class="col-md-5 wthree_banner_bottom_left">-->
<!---->
<!--            <!-- pop-up-box -->
<!--            <script src="public/js/jquery.magnific-popup.js" type="text/javascript"></script>-->
<!--            <!--//pop-up-box -->
<!--            <div id="small-dialog" class="mfp-hide">-->
<!--                <iframe src="https://www.youtube.com/embed/ZQa6GUVnbNM"></iframe>-->
<!--            </div>-->
<!--            <script>-->
<!--                $(document).ready(function() {-->
<!--                    $('.popup-with-zoom-anim').magnificPopup({-->
<!--                        type: 'inline',-->
<!--                        fixedContentPos: false,-->
<!--                        fixedBgPos: true,-->
<!--                        overflowY: 'auto',-->
<!--                        closeBtnInside: true,-->
<!--                        preloader: false,-->
<!--                        midClick: true,-->
<!--                        removalDelay: 300,-->
<!--                        mainClass: 'my-mfp-zoom-in'-->
<!--                    });-->
<!---->
<!--                });-->
<!--            </script>-->
<!--        </div>-->
        <div class="col-md-12 wthree_banner_bottom_right">
            <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs" style="text-align:center;">

                <ul id="myTab" class="nav nav-tabs" role="tablist" style="display:inline-block;">
                    <?php
                    global $array_category;
                    foreach ($array_category as $key => $value):?>
                        <li role="presentation" <?php if($key == 1){ echo "class='active'"; }?>><a href="#<?php echo $key ; ?>" id="<?php echo $key ; ?>-tab" role="tab" data-toggle="tab" aria-controls="<?php echo $key ; ?>"><?php echo $value?></a></li>
                    <?php endforeach;?>

                </ul>
                <div id="myTabContent" class="tab-content">

                    <?php
                    global $array_category;
                    foreach ($array_category as $key => $value):?>


                    <div role="tabpanel" class="tab-pane <?php if($key == 1){ echo " active in "; }?> fade" id="<?php echo $key;?>" aria-labelledby="<?php echo $key;?>-tab">
                        <div class="agile_ecommerce_tabs">
                        <?php foreach ($ProductPerCategorie[$key] as $element):?>

                            <div class="col-md-4 agile_ecommerce_tab_left">
                                <div class="hs-wrapper">
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <img src="public/images/<?php echo $element->getId();?>.jpg" alt=" " class="img-responsive" />
                                    <div class="w3_hs_bottom">
                                        <ul>
                                            <li>
                                                <a href="#" data-toggle="modal" data-target="#myModal1"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href="single.html"><?php echo $element->getLibelle(); ?></a></h5>
                                <p><span>$<?php echo $element->getPrix(); ?></span></p>
                                <div class="simpleCart_shelfItem">
                                    <form action="<?php echo getUrl(); ?>?controller=produit&action=add_to_cart" method="post">
                                        <input type="hidden" name="cmd" value="_cart" />
                                        <input type="hidden" name="id" value="<?php echo $element->getId(); ?>" />
                                        <input type="hidden" name="libelle" value="<?php echo $element->getLibelle(); ?>" />
                                        <input type="hidden" name="prix" value="<?php echo $element->getPrix(); ?>" />
                                        <button type="submit" name="add_to_cart" class="w3ls-cart">Add to cart</button>
                                    </form>
                                </div>
                            </div>



                        <?php endforeach;?>
                            <div class="clearfix"> </div>
                        </div>
                    </div>

                    <?php endforeach;?>



                </div>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //banner-bottom -->
<!-- modal-video -->

<div class="modal video-modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModal1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/9.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>Multimedia Home Accessories</h4>
                        <p>Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat.Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$180</span> <i class="item_price">$150</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Headphones">
                                <input type="hidden" name="amount" value="150.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModal2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/11.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>Quad Core Colorful Laptop</h4>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia  deserunt.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$880</span> <i class="item_price">$850</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Laptop">
                                <input type="hidden" name="amount" value="850.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModal3">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/14.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>Cool Single Door Refrigerator </h4>
                        <p>Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$950</span> <i class="item_price">$820</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Mobile Phone1">
                                <input type="hidden" name="amount" value="820.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModal4">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/17.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>New Model Mixer Grinder</h4>
                        <p>Excepteur sint occaecat laboris nisi ut aliquip ex ea
                            commodo consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$460</span> <i class="item_price">$450</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Mobile Phone1">
                                <input type="hidden" name="amount" value="450.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModal5">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/36.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>Dry Vacuum Cleaner</h4>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$960</span> <i class="item_price">$920</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Vacuum Cleaner">
                                <input type="hidden" name="amount" value="920.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="myModal6">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-5 modal_body_left">
                        <img src="public/images/37.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-7 modal_body_right">
                        <h4>Kitchen & Dining Accessories</h4>
                        <p>Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat.Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.</p>
                        <div class="rating">
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star-.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="rating-left">
                                <img src="public/images/star.png" alt=" " class="img-responsive" />
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <div class="modal_body_right_cart simpleCart_shelfItem">
                            <p><span>$280</span> <i class="item_price">$250</i></p>
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="w3ls_item" value="Induction Stove">
                                <input type="hidden" name="amount" value="250.00">
                                <button type="submit" class="w3ls-cart">Add to cart</button>
                            </form>
                        </div>
                        <h5>Color</h5>
                        <div class="color-quality">
                            <ul>
                                <li><a href="#"><span></span></a></li>
                                <li><a href="#" class="brown"><span></span></a></li>
                                <li><a href="#" class="purple"><span></span></a></li>
                                <li><a href="#" class="gray"><span></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- //modal-video -->
<!-- banner-bottom1 -->
<div class="banner-bottom1">
    <div class="agileinfo_banner_bottom1_grids">
        <div class="col-md-7 agileinfo_banner_bottom1_grid_left">
            <h3>20% <i>solde</i></span></h3>
            <a href="products.html">Achetez maintenant</a>
        </div>
        <div class="col-md-5 agileinfo_banner_bottom1_grid_right">
            <h4>Offres speciales</h4>
            <div class="timer_wrap">
                <div id="counter"> </div>
            </div>
            <script src="public/js/jquery.countdown.js"></script>
            <script src="public/js/script.js"></script>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //banner-bottom1 -->
<!-- special-deals -->
<div class="special-deals">
    <div class="container">
        <h2>Offres speciales</h2>
        <div class="w3agile_special_deals_grids">
            <div class="col-md-7 w3agile_special_deals_grid_left">
                <div class="w3agile_special_deals_grid_left_grid">
                    <img src="public/images/21.jpg" alt=" " class="img-responsive" />
                    <div class="w3agile_special_deals_grid_left_grid_pos1">
                        <h5>30%<span>Off/-</span></h5>
                    </div>
                    <div class="w3agile_special_deals_grid_left_grid_pos">
                        <h4>Nous offrons <span>les meilleurs promotions</span></h4>
                    </div>
                </div>
                <div class="wmuSlider example1">
                    <div class="wmuSliderWrapper">
                        <article style="position: absolute; width: 100%; opacity: 0;">
                            <div class="banner-wrap">
                                <div class="w3agile_special_deals_grid_left_grid1">
                                    <img src="public/images/t1.png" alt=" " class="img-responsive" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Laura</h4>
                                </div>
                            </div>
                        </article>
                        <article style="position: absolute; width: 100%; opacity: 0;">
                            <div class="banner-wrap">
                                <div class="w3agile_special_deals_grid_left_grid1">
                                    <img src="public/images/t2.png" alt=" " class="img-responsive" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Michael</h4>
                                </div>
                            </div>
                        </article>
                        <article style="position: absolute; width: 100%; opacity: 0;">
                            <div class="banner-wrap">
                                <div class="w3agile_special_deals_grid_left_grid1">
                                    <img src="public/images/t3.png" alt=" " class="img-responsive" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Rosy</h4>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <script src="public/js/jquery.wmuSlider.js"></script>
                <script>
                    $('.example1').wmuSlider();
                </script>
            </div>
            <div class="col-md-5 w3agile_special_deals_grid_right">
                <img src="public/images/20.jpg" alt=" " class="img-responsive" />
                <div class="w3agile_special_deals_grid_right_pos">
                    <h4>nouveaux   <span></span> coques</h4>
                    <h5>exculsif <span>chez</span>DaliPhone</h5>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<!-- //special-deals -->
<!-- new-products -->
<div class="new-products">
    <div class="container">
        <h3>Nouveaux Produits</h3>
        <div class="agileinfo_new_products_grids">
            <div class="col-md-3 agileinfo_new_products_grid">
                <div class="agile_ecommerce_tab_left agileinfo_new_products_grid1">
                    <div class="hs-wrapper hs-wrapper1">
                        <img src="public/images/25.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/23.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/24.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/22.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/26.jpg" alt=" " class="img-responsive" />
                        <div class="w3_hs_bottom w3_hs_bottom_sub">
                            <ul>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal2"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href="single.html">tablette</a></h5>
                    <div class="simpleCart_shelfItem">
                        <p><i class="item_price">350dt</i></p>
                        <form action="#" method="post">
                            <input type="hidden" name="cmd" value="_cart">
                            <input type="hidden" name="add" value="1">
                            <input type="hidden" name="w3ls_item" value="Red Laptop">
                            <input type="hidden" name="amount" value="500.00">
                            <button type="submit" class="w3ls-cart">Add to cart</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3 agileinfo_new_products_grid">
                <div class="agile_ecommerce_tab_left agileinfo_new_products_grid1">
                    <div class="hs-wrapper hs-wrapper1">
                        <img src="public/images/27.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/28.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/29.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/30.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/31.jpg" alt=" " class="img-responsive" />
                        <div class="w3_hs_bottom w3_hs_bottom_sub">
                            <ul>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href="single.html">hwawei p8</a></h5>
                    <div class="simpleCart_shelfItem">
                        <p><i class="item_price">1400dt</i></p>
                        <form action="#" method="post">
                            <input type="hidden" name="cmd" value="_cart">
                            <input type="hidden" name="add" value="1">
                            <input type="hidden" name="w3ls_item" value="Black Phone">
                            <input type="hidden" name="amount" value="370.00">
                            <button type="submit" class="w3ls-cart">Add to cart</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3 agileinfo_new_products_grid">
                <div class="agile_ecommerce_tab_left agileinfo_new_products_grid1">
                    <div class="hs-wrapper hs-wrapper1">
                        <img src="public/images/34.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/33.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/32.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/35.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/36.jpg" alt=" " class="img-responsive" />
                        <div class="w3_hs_bottom w3_hs_bottom_sub">
                            <ul>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal5"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href="single.html">Ecouteur samsung</a></h5>
                    <div class="simpleCart_shelfItem">
                        <p> <i class="item_price">20dt</i></p>
                        <form action="#" method="post">
                            <input type="hidden" name="cmd" value="_cart">
                            <input type="hidden" name="add" value="1">
                            <input type="hidden" name="w3ls_item" value="Kids Toy">
                            <input type="hidden" name="amount" value="100.00">
                            <button type="submit" class="w3ls-cart">Add to cart</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3 agileinfo_new_products_grid">
                <div class="agile_ecommerce_tab_left agileinfo_new_products_grid1">
                    <div class="hs-wrapper hs-wrapper1">
                        <img src="public/images/37.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/38.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/39.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/40.jpg" alt=" " class="img-responsive" />
                        <img src="public/images/41.jpg" alt=" " class="img-responsive" />
                        <div class="w3_hs_bottom w3_hs_bottom_sub">
                            <ul>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#myModal6"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href="single.html">power bank</a></h5>
                    <div class="simpleCart_shelfItem">
                        <p><span>$280</span> <i class="item_price">$250</i></p>
                        <form action="#" method="post">
                            <input type="hidden" name="cmd" value="_cart">
                            <input type="hidden" name="add" value="1">
                            <input type="hidden" name="w3ls_item" value="Induction Stove">
                            <input type="hidden" name="amount" value="250.00">
                            <button type="submit" class="w3ls-cart">Add to cart</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<!-- //new-products -->
<!-- top-brands -->
<div class="top-brands">
    <div class="container">
        <h3>Top Brands</h3>
        <div class="sliderfig">
            <ul id="flexiselDemo1">
                <li>
                    <img src="public/images/tb1.jpg" alt=" " class="img-responsive" />
                </li>
                <li>
                    <img src="public/images/tb2.jpg" alt=" " class="img-responsive" />
                </li>
                <li>
                    <img src="public/images/tb3.jpg" alt=" " class="img-responsive" />
                </li>
                <li>
                    <img src="public/images/tb4.jpg" alt=" " class="img-responsive" />
                </li>
                <li>
                    <img src="public/images/tb5.jpg" alt=" " class="img-responsive" />
                </li>
            </ul>
        </div>
        <script type="text/javascript">
            $(window).load(function() {
                $("#flexiselDemo1").flexisel({
                    visibleItems: 4,
                    animationSpeed: 1000,
                    autoPlay: true,
                    autoPlaySpeed: 3000,
                    pauseOnHover: true,
                    enableResponsiveBreakpoints: true,
                    responsiveBreakpoints: {
                        portrait: {
                            changePoint:480,
                            visibleItems: 1
                        },
                        landscape: {
                            changePoint:640,
                            visibleItems:2
                        },
                        tablet: {
                            changePoint:768,
                            visibleItems: 3
                        }
                    }
                });

            });
        </script>
        <script type="text/javascript" src="public/js/jquery.flexisel.js"></script>
    </div>
</div>
<!-- //top-brands -->
<!-- newsletter -->
<div class="newsletter">
    <div class="container">
        <div class="col-md-6 w3agile_newsletter_left">
            <h3>Newsletter</h3>
            <p>Excepteur sint occaecat cupidatat non proident, sunt.</p>
        </div>
        <div class="col-md-6 w3agile_newsletter_right">
            <form action="#" method="post">
                <input type="email" name="Email" placeholder="Email" required="">
                <input type="submit" value="" />
            </form>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //newsletter -->
<!-- footer -->
<div class="footer">
    <div class="container">
        <div class="w3_footer_grids">
            <div class="col-md-3 w3_footer_grid">
                <h3>Contact</h3>
                <ul class="address">
                    <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>12 rue Omar Ben Abdelaziz <span>RADES.</span></li>
                    <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">mohamedaliboumaiza@gmail.com</a></li>
                    <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+216 22 936 823</li>
                </ul>
            </div>
            <div class="col-md-3 w3_footer_grid">
                <h3>Information</h3>
                <ul class="info">
                    <li><a href="about.html">a propos de nous</a></li>
                    <li><a href="mail.html">Contactez nous</a></li>

                </ul>
            </div>
            <div class="col-md-3 w3_footer_grid">
                <h3>Categorie</h3>
                <ul class="info">
                    <li><a href="products.html">smartphones</a></li>
                    <li><a href="products1.html">tablettes</a></li>
                    <li><a href="products2.html">accessoires</a></li>
                </ul>
            </div>
            <div class="col-md-3 w3_footer_grid">
                <h3>Profile</h3>
                <ul class="info">
                    <li><a href="index.html">acceuils</a></li>
                    <li><a href="products.html">les offres du jour</a></li>
                </ul>
                <h4>Suivez nous</h4>
                <div class="agileits_social_button">
                    <ul>
                        <li><a href="#" class="facebook"> </a></li>
                        <li><a href="#" class="twitter"> </a></li>
                        <li><a href="#" class="google"> </a></li>
                        <li><a href="#" class="pinterest"> </a></li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
    <div class="footer-copy">
        <div class="footer-copy1">
            <div class="footer-copy-pos">
                <a href="#home1" class="scroll"><img src="public/images/arrow.png" alt=" " class="img-responsive" /></a>
            </div>
        </div>
        <div class="container">
            <p>&copy; 2017 Electronic Store. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
        </div>
    </div>
</div>
<!-- //footer -->
<!-- cart-js -->
<script src="public/js/minicart.js"></script>
<script>
   var  stat_form=false;
    $(document).ready(function(){
        $('.last').submit(function(e){
            e.preventDefault();
            if(stat_form == false){
                $('#w3lssbmincart').show();
                stat_form=true;
            }else if(stat_form == true){
                $('#w3lssbmincart').hide();
                stat_form=false;
            }

        });

        $('.sbmincart-closer').bind('click',function(e){
            stat_form=false;
            $('#w3lssbmincart').hide();
        });
    });
//    w3ls.render();

//    w3ls.cart.on('w3sb_checkout', function (evt) {
//        var items, len, i;
//
//        if (this.subtotal() > 0) {
//            items = this.items();
//
//            for (i = 0, len = items.length; i < len; i++) {
//            }
//        }
//    });
</script>
<!-- //cart-js -->
</body>
</html>
