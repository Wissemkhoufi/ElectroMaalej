<?php


if (!class_exists('Commande')) {
    include('models/commande.php');
}
if (!class_exists('ProduitCommande')) {
    include('models/produitCommande.php');
}

if (!class_exists('Client')) {
    include('models/client.php');
}

if (!class_exists('Produit')) {
    include('models/produit.php');
}
class ProduitController
{
    public function add_to_cart()
    {
        global $session;

        if($_POST['id']){

            if (!$session->session_exist('panier')) {

                $array = array();
                $session->create_session('panier', true);
                $session->set_Session_data('panier',$array);


            }else{

            }

            $panier = $session->get_Session_data('panier');
            $produit = Produit::findById($_POST['id']);
            if(isset($panier[$_POST['id']]) && isset($panier[$_POST['id']]['nb_element'])){
                $prev_numb_items = (int)$panier[$_POST['id']]['nb_element'];
                $total_nb_element = $prev_numb_items+1;


                if(isset($produit) && $produit->getQuantite() < $total_nb_element){
                    header('Location: ' . getUrl(). '?controller=store&action=index&type=error&message=quantite produit superieur a la quantite disponible');
                    exit();
                }

                $panier[$_POST['id']]['nb_element'] = $total_nb_element;
                $panier[$_POST['id']]['prix'] = $_POST['prix'];
                $panier[$_POST['id']]['libelle'] = $_POST['libelle'];


                $session->set_Session_data('panier',$panier);

            }else{
                if(isset($produit) && $produit->getQuantite() < 1){
                    header('Location: ' . getUrl(). '?controller=store&action=index&type=error&message=quantite produit superieur a la quantite disponible');
                    exit();
                }
                $panier[$_POST['id']] = array();
                $panier[$_POST['id']]['nb_element'] = 1;
                $panier[$_POST['id']]['prix'] = $_POST['prix'];
                $panier[$_POST['id']]['libelle'] = $_POST['libelle'];
                $session->set_Session_data('panier',$panier);
            }
            header('Location: ' . getUrl(). '?controller=store&action=index');

        }else{
            header('Location: ' . getUrl(). '?controller=store&action=index');
        }




    }


    public function delete_from_cart()
    {
        global $session;

        if ($session->session_exist('panier')) {

            if(isset($_GET['id'])){
                $panier = $session->get_Session_data('panier');
                unset($panier[$_GET['id']]);
                $session->set_Session_data('panier',$panier );
            }


        }

        header('Location: ' . getUrl(). '?controller=store&action=index');
    }
}