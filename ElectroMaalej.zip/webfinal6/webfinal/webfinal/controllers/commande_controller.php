<?php

if (!class_exists('Produit')) {
    include('models/produit.php');
}
if (!class_exists('Paiement')) {
    include('models/paiement.php');
}
if (!class_exists('Commande')) {
    include('models/commande.php');
}

if (!class_exists('Client')) {
    include('models/client.php');
}

if (!class_exists('ProduitCommande')) {
    include('models/produitCommande.php');
}
  class CommandeController {

        public function __constructor(){


        }



      public function passer_commande($array = null)
        {
            global $session;

            if($session->session_exist('panier')) {
                $total_panier = 0;
                foreach ($session->get_Session_data('panier') as $k => $element):
                    $total_ligne = 0;
                    $total_ligne = $element['prix'] * $element['nb_element'];
                    $total_panier += $total_ligne;
                endforeach;


            }
            $sold = 0;

            if($session->session_exist('Client')) {
                $client = $session->get_Session_data('Client');
                $paiment = Paiement::findByClientId($client['id']);
                $sold = (int)$paiment->getSold();


            if((int)$sold <  (int)$total_panier){
                header('Location: ' . getUrl() . '?controller=store&action=index&type=error&message=Votre solde est insufisant : '.$sold);

                exit();

            }else{

                $commande = new Commande();
                $commande->setDate( date("Y-m-d"));
                $commande->setPrixTotal($total_panier);
                $commande->setClient_id($client['id']);
                $last_id = $commande->create();


                foreach($session->get_Session_data('panier') as $K => $element ){

                $ligneCommande = new ProduitCommande();
                $ligneCommande->setProduitId($K);
                $ligneCommande->setCommandeId($last_id);
                $produit = Produit::findById($K);
                $quantite_produit= $produit->getQuantite() - $element['nb_element'] ;
                $produit->setQuantite($quantite_produit);
                $produit->update();
                $ligneCommande->setQuantite( $element['nb_element']);
                $ligneCommande->create();

                }

                $rest =  $sold-$total_panier ;
                $paiment->setSold((int)$rest);
                $paiment->updateSold();
                if ($session->session_exist('panier')) {
                    $session->remove_session('panier');

                }
            }

            }


            header('Location: ' . getUrl(). '?controller=store&action=index&type=success&message=commande effectuee avec success');
            exit();
        }

      public function error() {
          require_once('views/pages/error.php');
      }
  }
