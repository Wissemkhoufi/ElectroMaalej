<?php



if (!class_exists('Client')) {
    include('models/client.php');
}


class ClientController
{
    public function sinscrire()
    {
        require_once('views/client/ajoutclient.php');
    }
    
    public function save_client()
    {
        
        if(isset($_POST['email']) && isset($_POST['password']) && isset($_POST['dateNaissance']) && isset($_POST['adresse']) && isset($_POST['role']) && isset($_POST['nom']) && isset($_POST['prenom']) ){
        Client::Add_client($_POST['email'],$_POST['password'],$_POST['dateNaissance'],$_POST['adresse'],$_POST['role'],$_POST['nom'],$_POST['prenom']);
header('Location: ' . getUrl(). '?controller=store&action=index&type=success&message=votre compte a été crée avec succès!');

         
    }}
        public function edit()
{
    require_once('views/edit.php');

}
    public function update()
{
    if(isset($_POST['email']) && isset($_POST['password']) && isset($_POST['dateNaissance']) && isset($_POST['adresse']) && isset ($_POST['nom'])&& isset ($_POST['prenom']) ){
    Client::update($_POST['email'],$_POST['password'],$_POST['dateNaissance'],$_POST['adresse'],$_POST['nom'],$_POST['prenom']);
    
}
}

public function login(){

global $session;

if ($session->session_exist('Admin')){

    header('Location: ' . getUrl() . '?controller=admin&action=index');

}elseif($session->session_exist('Client')){
    header('Location: ' . getUrl() . '?controller=store&action=index');

}else{
$email = null;

if (isset($_POST['login'])) {


$client = Client::findByEmail($_POST['email'], true);
$session->create_session('message', false);

if (isset($client) && !empty($client) && $_POST['password'] == $client['password']) {

    if ($client['role'] == 'admin') {
        $session->create_session('Admin', true);
        $session->set_Session_data('Admin', $client);
        $session->set_Session_data('success', 'Login effectuee avec success');
        header('Location: ' . getUrl() . '?controller=admin&action=index');
    }elseif($client['role'] == 'client'){
        $session->create_session('Client', true);
        $session->set_Session_data('Client', $client);
        $session->set_Session_data('success', 'Login effectuee avec success');
        header('Location: ' . getUrl() . '?controller=store&action=index');
    }
} else {
    $session->set_Session_data('error', 'utilisateur introuvable ou information erronée');
    header('Location: ' . getUrl() . '?controller=store&action=index&type=error&message=utilisateur introuvable ou information erronée');
}


?></br><?php


}
}


require_once('views/store/index.php');
}



public function logout()
{
    global $session;

    if ($session->session_exist('Client')) {
        $session->remove_session('Client');
        header('Location: ' . getUrl() . '?controller=store&action=index');

    }

    if ($session->session_exist('panier')) {
        $session->remove_session('panier');
        header('Location: ' . getUrl() . '?controller=store&action=index');

    }
}
}