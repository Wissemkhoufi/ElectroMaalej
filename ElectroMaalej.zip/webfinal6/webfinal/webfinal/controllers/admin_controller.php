<?php


if (!class_exists('Commande')) {
    include('models/commande.php');
}
if (!class_exists('ProduitCommande')) {
    include('models/produitCommande.php');
}

if (!class_exists('Client')) {
    include('models/client.php');
}


class AdminController
{
public function __constructor()
{

}

public function index()
{
    $all_commande = Commande::all();


    require_once('views/admin/index.php');
}
public function afficher()
{
    $all_client = Client::all();


    require_once('views/admin/index.php');
}
public function chart()
{
    $all_commande = Commande::all();


    require_once('views/admin/chart.php');
}


public function getCommandeBydate()
{


    if(!empty($_POST['date'])){
        $string_Date= strtotime($_POST['date']);
        $date = date('Y-m-d',$string_Date);
        $commande_liste = Commande::getProductByDate($date);
    }else{
        $commande_liste=false;
    }
    header('Content-type: application/json');//pour pouvoir recevoir les informations depuis ajax

    echo json_encode($commande_liste);
}

public function login() {

global $session;

if ($session->session_exist('Admin')){

    header('Location: ' . getUrl() . '?controller=admin&action=index');

}elseif($session->session_exist('Admin')){
    header('Location: ' . getUrl() . '?controller=store&action=index');

}else{
$email = null;

if (isset($_POST['login'])) {


$client = Client::findByEmail($_POST['email'], true);
$session->create_session('message', false);
if (isset($client) && !empty($client) && $_POST['password'] == $client->getPassword()) {

    if ($client->getRole() == 'admin') {
        $session->create_session('Admin', true);
        $session->set_Session_data('Admin', $client);
        $session->set_Session_data('success', 'Login effectuee avec success');
        header('Location: ' . getUrl() . '?controller=admin&action=index');
    }elseif($client->getRole() == 'client'){
        $session->create_session('Client', true);
        $session->set_Session_data('Client', $client);
        $session->set_Session_data('success', 'Login effectuee avec success');
        header('Location: ' . getUrl() . '?controller=store&action=index');
    }
} else {
    $session->set_Session_data('error', 'utilisateur introuvable ou information erronée');

}


?></br><?php


}
}

require_once('views/admin/login.php');
}
public function logout()
{
    global $session;

    if ($session->session_exist('Admin')) {
        $session->remove_session('Admin');
        header('Location: ' . getUrl() . '?controller=admin&action=index');

    }
}

public function error()
{

    require_once('views/pages/error.php');
}

}