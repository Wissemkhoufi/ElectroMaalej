<?php


if (!class_exists('produit')) {
    include('models/Produit.php');
}

class StoreController
{

    public function index() {
        global $session;

        $ProductPerCategorie = array();
        $produit_Telephone = Produit::findByCategorie(1);
        $produit_Tablette= Produit::findByCategorie(2);
        $produit_Accessoires = Produit::findByCategorie(3);
        $ProductPerCategorie [1] =$produit_Telephone;
        $ProductPerCategorie [2] =$produit_Tablette;
        $ProductPerCategorie [3] =$produit_Accessoires;


 
        require_once('views/store/index.php');
    }



    public function show($array=null) {
        
        if (!isset($_GET['id']))
            return call('pages', 'error');

        die;
        
        $post = Post::find($_GET['id']);
        require_once('views/posts/show.php');
    }

}