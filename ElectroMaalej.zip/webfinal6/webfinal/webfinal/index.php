<?php
require_once('session.php');
    $session = new Sessions();

  require_once('connexion.php');
  require_once('routes.php');
function getValue($array, $key)
{
    foreach($array as $k=>$value)
    {
        if($k==$key)
        {
            return $value;
        }
    }
    return null;
}

    if(($session->session_exist('Client'))){
        if (!class_exists('Paiement')) {
            include('models/paiement.php');
        }
            $client = $session->get_Session_data('Client');
            $paiment = Paiement::findByClientId($client['id']);
            $sold = (int)$paiment->getSold();

    }
    $array_category =array('1'=>'Telephone',
                            '2'=>'Tablette',
                            '3'=>'Accessoires');



    $params = array();
  if (isset($_GET['controller']) && isset($_GET['action'])) {
    $controller = $_GET['controller'];
    $action     = $_GET['action'];
  } else {
    $controller = 'store';
    $action = 'index';
  }

$_GET['controller']= '';
$_GET['action']= '';

    function getURl(){
        $array = parse_url($_SERVER['REQUEST_URI']);


        if(isset($array['path'])){
            $path = $array['path'];
        }else{
            $path = '/';
        }
        return  $path;
    }

    call( $controller ,$action);


