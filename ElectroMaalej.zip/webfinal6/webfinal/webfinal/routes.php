<?php
  function call($controller, $action,$array = null) {
     $controller_name = $controller;
    require_once('controllers/' . $controller . '_controller.php');

    switch($controller) {
      case 'pages':
        $controller = new PagesController();
      break;
        case 'admin':
         $controller = new AdminController();
         break;
      case 'commande':
          $controller = new CommandeController();
          break;
      case 'client':
            $controller = new ClientController();
            break;
      case 'store':
          $controller = new StoreController();
          break;
      case 'paiement':
          $controller = new PaiementController();
          break;

      case 'produit':
            $controller = new ProduitController();
            break;
      case 'produitCommande':
            $controller = new produitCommandeController();
            break;
      case 'posts':
        require_once('models/post.php');
        $controller = new PostsController();
      break;
        case 'modeles':
            require_once('models/modele.php');
            $controller = new ModelesController();
            break;
    }




  
  $controllers = array('pages' => ['home', 'error'],
                        'posts' => ['index', 'show'],
                        'client' => ['sinscrire','save_client','login','logout','update','edit'],
                        'admin' => ['index','login','chart','getCommandeBydate','afficher'],
                        'store' => ['index'],
                        'produit'=>['add_to_cart','delete_from_cart'],
                        'commande' => ['ajouter_au_panier', 'show','passer_commande'],
                        'modeles' => ['index', 'add', 'save','search', 'edit', 'update','delete','remove']);

  $controllers_admin =array('admin'=>['index','logout','chart']);
  $controllers_client=array('commande' => ['add_to_cart','passer_commande'],
                            'produit'=>['add_to_cart','delete_from_cart'],
                            'client'=>['logout']);

  if (array_key_exists($controller_name, $controllers)) {
    if (!in_array($action, $controllers[$controller_name])) {


        call('pages', 'error');
    }
    global $session;
    if (array_key_exists($controller_name, $controllers_admin)) {

        if (in_array($action, $controllers_admin[$controller_name]) && !($session->session_exist('Admin'))) {

            header('Location: '.geturl().'?controller=store&action=index');
            exit();
        }
    }
    if (array_key_exists($controller_name, $controllers_client)){
            if (in_array($action, $controllers_client[$controller_name]) && !($session->session_exist('Client'))) {


                header('Location:'.getURl().'?controller=store&action=index&type=error&message=vous devez vous connectee');
                exit();
            }
    }
  } else {

    call('pages', 'error');


  }
      $controller->{ $action }($array);
      if ($session->session_exist('success')) {
          $session->remove_session('success');

      }
      if ($session->session_exist('error')) {
          $session->remove_session('error');

      }

  }
