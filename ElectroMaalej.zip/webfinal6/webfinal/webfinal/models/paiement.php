<?php


if(!class_exists('Client')) {
    include('client.php');
}
if(!class_exists('Commande')) {
    include('commande.php');
}

class Paiement
{
    private $id;
    private $sold;
    private $RIB;
    private $client_id;
    private $commande_id ;

    public function __construct($client_id=null,$commande_id=null)
    {
        if($commande_id !=null){
            $this->commande_id = $commande_id;
        }

        if($client_id !=null){
            $this->client_id = $client_id;
        }

        $this->setClient($client_id);



    }

   
    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    
    public function getSold()
    {
        return $this->sold;
    }

    

    public function setSold($sold)
    {
        $this->sold= $sold;
    }

    
    public function getRIB()
    {
        return $this->RIB;
    }

    
    public function setRIB($RIB)
    {
        $this->RIB = $RIB;
    }

    public function getCommande_id()
    {
        return $this->commande_id;
    }

    
    public function setCommande_id($commande_id)
    {
        $this->commande_id = $commande_id;
    }

    public function setClient_id($client_id){

        $this->client_id =$client_id;
        $this->setClient($client_id);
    }

    public function getClient_id(){

        return $this->client_id;

    }

    public function setClient($client_id){

        $client = new client();

        if(!isset($this->client)){
            $this->client = $client->findById($client_id);
        }


    }

    public function Create()
    {
        $db=Db::getInstance();
        $req="INSERT INTO paiement (`RIB`,`client_id`,`commande_id`) VALUES('".$this->RIB."','".$this->client_id."','".$this->commande_id."')";

        $db->query($req);
    }



    public static function findById($id)
    {
        $db=Db::getInstance();
        $req=$db->prepare("SELECT * FROM paiement WHERE Id=:id");
        $req->execute(array('id'=>$id));
        $modele=$req->fetch();
        $m=new paiement();
        $m->setDate($modele['sold']);
        $m->setId($modele['id']);
        $m->setRIB($modele['RIB']);
        $m->setPrixTotal($modele['prix_total']);
        $m->setClient_id($modele['client_id']);


        return $m;
    }


    public static function findByClientId($id)
    {
        $db=Db::getInstance();
        $req=$db->prepare("SELECT * FROM paiement WHERE client_id=:id");
        $req->execute(array('id'=>$id));
        $modele=$req->fetch();
        $m=new paiement();
        $m->setSold($modele['sold']);
        $m->setRIB($modele['RIB']);
        $m->setId($modele['id']);
        $m->setClient_id($modele['client_id']);


        return $m;
    }

    public function updateSold()
    {
        $db=Db::getInstance();
        $req="UPDATE Paiement SET sold='".$this->getSold()."' WHERE Id=".$this->getId();
        $db->query($req);
    }



}