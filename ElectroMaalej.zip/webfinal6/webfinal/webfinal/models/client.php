<?php

class Client
{
private $id;
private $email;
private $password;
private $date_naissance;
private $adresse;
private $prenom;
private $nom;
private $sold;
private $role;

public function __construct()
{

}


public function getId()
{
return $this->id;
}

public function setId($id)
{
$this->id = $id;
}


public function getEmail()
{
    return $this->email;
}

public function setEmail($email)
{
    $this->email = $email;
}


public function setPassword($password)
{
$this->password = $password;
}
public function getPassword()
{
   return $this->password;
}


public function getDateNaissance()
{
return $this->date_naissance;
}
public function setDateNaissance($date_naissance)
{
    $this->date_naissance =$date_naissance ;
}


public function setAdresse($adresse)
{
$this->adresse = $adresse;
}

public function getAdresse()
{
return $this->adresse;
}

    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    public function getNom()
    {
        return $this->nom;
    }

    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

    public function getPrenom()
    {
        return $this->prenom;
    }

public function getRole()
{
return $this->role;
}

public function setRole($role)
{
$this->role = $role;
}


public static function Add_client($email,$password,$dateNaissance,$adresse,$role,$nom,$prenom)
    {
    $db=Db::getInstance();
    $requ=$db->prepare("INSERT into client
    (email,password,dateNaissance,adresse,role,nom,prenom)
    values ( :email, :password, :dateNaissance, :adresse, :role,:nom,:prenom )");
     $requ->execute(array(
        'email'=> $email, 
        'password'=> $password,
        'dateNaissance'=> $dateNaissance,
        'adresse'=> $adresse,
        'role'=>$role,
        'nom'=>$nom,
        'prenom'=>$prenom)
       );
        
    }
    public static function update($email,$password,$dateNaissance,$adresse,$nom,$prenom)
    {
        $db= Db::getInstance();
        $req= $db->prepare("UPDATE client SET email= :email , password= :password , dateNaissance = :dateNaissance , adresse= :adresse, nom=:nom , prenom=:prenom");
      $req->execute(array('email' => $email, 'password' => $password,'dateNaissance' => $dateNaissance, 'adresse' => $adresse ,'nom'=>$nom , 'prenom'=>$prenom));
        
    }


public static function findById($id)
{
$db=Db::getInstance();
$req=$db->prepare("SELECT * FROM Client WHERE Id=:id");
$req->execute(array('id'=>$id));
$res=$req->fetch();
$client=new Client();

$client->setId($res['id']);
$client->setEmail($res['email']);
$client->setNom($res['nom']);
$client->setPassword($res['password']);
$client->setPrenom($res['prenom']);
$client->setEmail($res['email']);
$client->setDateNaissance($res['dateNaissance']);
$client->setAdresse($res['adresse']);

return $client;
}

public static function findByEmail($email,$table = false)
{
$db=Db::getInstance();
$req=$db->prepare("SELECT * FROM client WHERE email = '".$email."' ");
$req->execute();

$list=[];


    if(!$table){
        $m=$req->fetch();
    if(isset($m) && !empty($m)) {

        $client = new Client();
        $client->setId($m['id']);
        $client->setEmail($m['email']);
        $client->setNom($m['nom']);
        $client->setPassword($m['password']);
        $client->setPrenom($m['prenom']);
        $client->setDateNaissance($m['dateNaissance']);
        $client->setAdresse($m['adresse']);
        $client->setSold($m['sold']);
        $client->setRole($m['role']);

        return $client;
    }else{
        return false;
    }

    }else{
        $m=$req->fetch();

        return $m;
    }
}

public function updateSold()
{
    $db=Db::getInstance();
    $req="UPDATE Client SET sold='".$this->getSold()."' WHERE Id=".$this->getId();
    $db->query($req);
}
public static function all()
    {
        $list = [];
        $db=Db::getInstance();
        $req = $db->query('SELECT  * FROM client');
        foreach ($req->fetchAll () as $temp) {
            $list [] = new Client($temp['id'],$temp['email'],$temp['password'],$temp['dateNaissance'],$temp['adresse'],$temp['role'],$temp['nom'],$temp['prenom']);

        }
        return $list;
    }

}