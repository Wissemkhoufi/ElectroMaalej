<?php


if(!class_exists('Produit')) {
    include('models/produit.php');
}

class Produitcommande
{

    private $commande_id;
    private $produit_id;
    private $quantite;
    private $produit;

    public function __construct()
    {


    }

    
    public function getCommandeId()
    {
        return $this->commande_id;
    }

    public function setCommandeId($id)
    {
        $this->commande_id = $id;
    }

   
    public function getProduitId()
    {
        return $this->produit_id;
    }

    

    public function setProduitId($produit_id)
    {
        $this->produit_id= $produit_id;
    }

   

    public function setQuantite($quantite){

        $this->quantite =$quantite ;
    }

    public function getQuantite(){

        return $this->quantite;

    }

    public function setProduit($produit){

        $this->produit =$produit ;
    }

    public function getProduit(){

        return $this->produit;

    }



    public function Create()
    {
        $db=Db::getInstance();
        $req="INSERT INTO commande_produit (`commande_id`,`produit_id`,`quantite`) VALUES('".$this->commande_id."','".$this->produit_id."','".$this->quantite."')";

        $db->query($req);
    }



    public static function findByCommandeId($id)
    {
        $db=Db::getInstance();
        $req=$db->prepare("SELECT * FROM commande_produit WHERE commande_id=:id");
        $req->execute(array('id'=>$id));

        $list=[];

        foreach($req->fetchAll() as $m) {

            $modele = new Produitcommande();
            $modele->setProduitId($m['produit_id']);
            $modele->setCommandeId($m['commande_id']);
            $modele->setQuantite($m['quantite']);

            $modele->setProduit(Produit::findById($m['produit_id']));
            $list[]=$modele;

        }

        return $list;

    }



}