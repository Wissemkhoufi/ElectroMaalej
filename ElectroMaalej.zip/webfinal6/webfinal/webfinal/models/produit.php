<?php


class Produit
{
    private $id;
    private $libelle;
    private $categorie;
    private $prix;
    private $quantite;

    public function __construct()
    {

    }

    
    public function getId()
    {
        return $this->id;
    }

    
    public function setId($id)
    {
        $this->id = $id;
    }

   
    public function getLibelle()
    {
        return $this->libelle;
    }

    public function setLibelle($libelle)
    {
        return $this->libelle = $libelle;
    }

    
    public function setCategorie($categorie)
    {
        $this->categorie = $categorie;
    }

    
    public function getCategorie()
    {
        return $this->categorie;
    }

    
    public function setPrix($prix)
    {
        $this->prix = $prix;
    }

    public function getPrix()
    {
       return  $this->prix;
    }

    public function getQuantite()
    {
        return $this->quantite;
    }

    public function setQuantite($quantite)
    {
        $this->quantite = $quantite;
    }


    public function Create()
    {
        $db=Db::getInstance();
        $req="INSERT INTO Produit (`libelle`,`categorie`,`prix`,`quantite`) VALUES('".$this->libelle."','".$this->categorie."','".$this->prix."','".$this->quantite."')";

        $db->query($req);
    }

    public static function all() {
        $list = [];
        $db = Db::getInstance();
        $req = $db->query('SELECT * FROM produit');
        foreach($req->fetchAll() as $modele) {
            $m=new Produit();
            $m->setPrix($modele['prix']);
            $m->setId($modele['id']);
            $m->setLibelle($modele['libelle']);
            $m->setCategorie($modele['categorie']);
            $m->setQuantite($modele['quantite']);
            $list[] = $m;
        }

        return $list;
    }




    public static function findById($id)
    {
        $db=Db::getInstance();
        $req=$db->prepare("SELECT * FROM Produit WHERE id=:id");
        $req->execute(array('id'=>$id));
        $res=$req->fetch();
        $produit=new Produit();
        $produit->setId($res['id']);
        $produit->setLibelle($res['libelle']);
        $produit->setCategorie($res['categorie']);
        $produit->setQuantite($res['quantite']);
        $produit->setPrix($res['prix']);

        return $produit;
    }

    public static function findByLibelle($libelle)
    {
        $db=Db::getInstance();
        $libelle=strtolower($libelle);
        $req=$db->prepare("SELECT * FROM Produit WHERE Libelle like '%".$libelle."%'");
        $req->execute();
        $list=[];
        foreach($req->fetchAll() as $m)
        {
            $produit=new Produit();
            $produit->setId($m['id']);
            $produit->setLibelle($m['libelle']);
            $produit->setCategorie($m['categorie']);
            $produit->setQuantite($m['quantite']);
            $produit->setPrix($m['prix']);
            $list[]=$produit;
        }

        return $list;
    }
    public static function findByCategorie($categorie)
    {
        $db=Db::getInstance();
        $libelle=strtolower($categorie);
        $req=$db->prepare("SELECT * FROM Produit WHERE categorie = '".$libelle."'");
        $req->execute();
        $list=[];
        foreach($req->fetchAll() as $m)
        {
            $produit=new Produit();
            $produit->setId($m['id']);
            $produit->setLibelle($m['libelle']);
            $produit->setCategorie($m['categorie']);
            $produit->setQuantite($m['quantite']);
            $produit->setPrix($m['prix']);
            $list[]=$produit;
        }

        return $list;
    }

    public function update()
    {
        $db=Db::getInstance();
        $req="UPDATE Produit SET quantite ='".$this->getQuantite()."' WHERE Id=".$this->getId();
        $db->query($req);
    }



}