<?php


if(!class_exists('ProduitCommande')){
    include('models/produitCommande.php');
}

if(!class_exists('Client')){
    include('models/client.php');
}



class commande
{
    private $id;
    private $date;
    private $prix_total;
    private $client_id;
    private $client ;
    private $produitCommande ;
    public function __construct($client_id=null)
    {
        if(isset($client_id)) {


            $this->client_id = $client_id;
            $this->setClient($client_id);
        }

    }

    
    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

   
    public function getDate()
    {
        return $this->date;
    }

    

    public function setDate($date)
    {
        $this->date= $date;
    }
    public function getPrixTotal()
    {
        return $this->prix_total;
    }

    public function getProduitCommande()
    {
        return $this->produitCommande;
    }

    public function setProduitCommande($produitCommande)
    {
        return $this->produitCommande = $produitCommande;
    }

    
    public function setPrixTotal($prix)
    {
        $this->prix_total = $prix;
    }

    public function setClient_id($client_id){

        $this->client_id =$client_id ;

    }

    public function getClient_id(){

        return $this->client_id;

    }

    public function setClient($client){


         $this->client = $client;

    }
    public function getClient(){


        return $this->client ;

    }
    public function Create()
    {
        $db=Db::getInstance();
        $req="INSERT INTO commande (`date`,`prix_total`,`client_id`) VALUES('".$this->date."','".$this->prix_total."','".$this->client_id."')";

        $db->query($req);
        $last_id = $db->lastInsertId();

        return $last_id;


    }

    public static function all() {

        $list = [];
        $db = Db::getInstance();
         $req = $db->query('SELECT * FROM Commande ORDER BY id DESC ');

        foreach($req->fetchAll() as $modele) {
            $m=new Commande();
            $m->setDate($modele['date']);
            $m->setId($modele['id']);
            $m->setPrixTotal($modele['prix_total']);
            $m->setClient_id($modele['client_id']);
            $m->setClient(Client::findById($modele['client_id']));
            $m->setProduitCommande(ProduitCommande::findByCommandeId($modele['id']));
            $list[] = $m;
        }

        return $list;
    }


    public static function getProductByDate($date) {

        $array_prod = [];
        $db = Db::getInstance();
        $req = $db->query('SELECT cmd_pro.produit_id,pro.libelle,  SUM(cmd_pro.quantite) as sum
                            FROM commande_produit cmd_pro
                            JOIN commande cmd
                              ON cmd.id=cmd_pro.commande_id
                            JOIN produit pro
                              ON pro.id=cmd_pro.produit_id
                               where cmd.date = \''.$date.'\'
                            GROUP BY cmd_pro.produit_id');

        $array_prod = $req->fetchAll();


        return $array_prod;
    }

    public static function allJoin() {

        $list = [];
        $db = Db::getInstance();
        $req = $db->query('SELECT * FROM Commande left join ');

        foreach($req->fetchAll() as $modele) {
            $m=new Commande();
            $m->setDate($modele['date']);
            $m->setId($modele['id']);
            $m->setPrixTotal($modele['prix_total']);
            $m->setClient_id($modele['client_id']);
            $m->setProduitCommande(ProduitCommande::findByCommandeId($modele['id']));
            $list[] = $m;
        }

        return $list;
    }

    public static function findById($id)
    {
        $db=Db::getInstance();
        $req=$db->prepare("SELECT * FROM Commande WHERE Id=:id");
        $req->execute(array('id'=>$id));
        $res=$req->fetch();
        $m=new Commande();
        $m->setDate($modele['date']);
        $m->setId($modele['id']);
        $m->setPrixTotal($modele['prix_total']);
        $m->setClient_id($modele['client_id']);


        return $m;
    }

    public static function findByClient($client_id)
    {
        $db=Db::getInstance();
        $client=strtolower($client_id);
        $req=$db->prepare("SELECT * FROM commande WHERE client_id  = '".$client_id."'");
        $req->execute();
        $list=[];
        foreach($req->fetchAll() as $m)
        {   $modele = new Commade();
            $modele->setDate($m['date']);
            $modele->setId($m['id']);
            $modele->setPrixTotal($m['prix_total']);
            $modele->setClient_id($m['client_id']);
            $list[]=$modele;
        }

        return $list;
    }



}